﻿// See https://aka.ms/new-console-template for more information
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;
using OpenQA.Selenium.Edge;
using SeleniumUndetectedChromeDriver;
using System.Linq.Expressions;

const string BASE_TEST_URL = "https://www.delta.com";
IWebDriver driver = UndetectedChromeDriver.Create(driverExecutablePath: await new ChromeDriverInstaller().Auto());
driver.Navigate().GoToUrl(BASE_TEST_URL);
var title = driver.Title;
string lastVisitedUrl = BASE_TEST_URL;

WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(20));
driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromMilliseconds(500);
waitUntilNavigationComplete();

driver.Manage().Window.Maximize();

// From Airport
selectAirport("Lax", "fromAirportName");
// To Airport
selectAirport("Atlanta", "toAirportName");

// Select the Trip Type
selectItemFromSelectElement("One Way", "selectTripType");

// Select Number of Passengers
selectItemFromSelectElement("1 Passengers", "passengers");

// Select Departure Date
selectDateFromCalendarElement("05/12/2025", "departureDate");

// Click the Search Button
driver.FindElement(By.Id("btn-book-submit")).Click();
waitUntilNavigationComplete();

// Checks and processes an optional flexible page
continueIfFlexiblePageAppear();

bool isSuccessful = gotoSearchResultPage();

if (isSuccessful)
{
    wait.Until(d =>
    {
        try
        {
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            // Click on the first available flight
            driver.FindElement(By.Id("grid-row-0-fare-cell-desktop-MAIN")).Click();

            return true;
        }
        catch
        {
            return false;
        }
    });

    continueIfFlexiblePageAppear();

    // Select the Price by Upsell Drawer
    bool success = selectPriceByUpsellDrawerClick();

    if (!success)
    {
        // Select the Price by Modal Dialog
        success = selectPriceByModalDialogClick();
    }

    if (success)
    {
        // Click on Continue To Review & Pay Button
        continueToReviewButtonClick();

        // Enter the Passenger details for only 1 Passenger
        enterPassengerDetails();

        // Enter the Contact info
        enterContactInfo();

        // Enter Credit Card details
        enterCreditCard();

        // Click the Complete Purchase button
        driver.FindElement(By.CssSelector("[data-cy='idp-button-Complete Purchase']")).Click();
    }
}

//driver.Quit();
Console.WriteLine(title);


void enterCreditCard()
{
    changeTextboxText("5563783573849245", "id_paymentCardNum_creditDebit"); // Enter Credit Card No 
    changeTextboxText("0127", "id_expirationDate_creditDebit"); // Enter Credit Card Expiry Date
    changeTextboxText("012", "id_paymentCardSecurityCode_creditDebit"); // Enter Credit Card CVV
    changeTextboxText("Bobby Micheal Opara", "id_nameOnCard_creditDebit"); // Enter Credit Card Name
    changeTextboxText("Suite 13 North west Street", "id_addressLine1Text_creditDebit"); // Enter Credit Card Address Line 1
    changeTextboxText("West side", "id_addressLine2Text_creditDebit"); // Enter Credit Card Address Line 2
    changeTextboxText("Atlanta", "id_cityLocalityName_creditDebit"); // Enter Credit Card City
    selectItemFromSelectElement_creditCard("Georgia", "id_countrySubdivisionCode_creditDebit"); // Enter State
    changeTextboxText("234617", "id_postalCode_creditDebit"); // Enter Credit Card Postal Code
}

void enterContactInfo()
{
    selectItemFromSelectElement_reviewPage("United States (1)", "input_country_contact"); // Select Cointry Code
    changeTextboxText("67354672839", "contact_info_phone"); // Enter Contact Phone number
    changeTextboxText("bobby_opara@gmail.com", "contact_info_email"); // Enter Email
}

void enterPassengerDetails()
{
    changeTextboxText("Bobby", "firstName_0"); // Enter First Name
    changeTextboxText("Micheal", "middleName_0"); // Enter Middle Name
    changeTextboxText("Opara", "lastName_0"); // Enter Last Name
    selectItemFromSelectElement_reviewPage("Jr", "suffix_0"); // Select the Suffix
    selectItemFromSelectElement_reviewPage("Mar", "dobmonth_0"); // Select Month of Birth
    selectItemFromSelectElement_reviewPage("20", "dobday_0"); // Select Day of Birth
    selectItemFromSelectElement_reviewPage("2020", "dobyear_0"); // Select Year of Birth
    selectItemFromSelectElement_reviewPage("Male (M)", "gender_0"); // Select Gender
}

bool waitUntilNavigationComplete()
{
    while (driver.Url.Equals(lastVisitedUrl))
    {

    }

    lastVisitedUrl = driver.Url;
    return true;
}

void continueIfFlexiblePageAppear()
{
    string url = driver.Url;
    if (url.StartsWith("https://www.delta.com/flightsearch/flexible-dates"))
    {
        string continueButton = "idp-button-CONTINUE";
        // confirms if the flexible date page shows up
        driver.FindElement(By.CssSelector($"[data-cy={continueButton}]")).Click();
        waitUntilNavigationComplete();
    }
}

void continueToReviewButtonClick()
{
    wait.Until(d =>
    {
        try
        {
            IWebElement selectList_Element = driver.FindElement(By.CssSelector("[data-cy='idp-button-Continue to Review & Pay']"));
            selectList_Element.Click();

            return true;
        }
        catch
        {
            return false;
        }
    });
}

bool selectPriceByModalDialogClick()
{
    IReadOnlyList<IWebElement> selectList_Element = driver.FindElements(By.CssSelector("[data-test-modal-wrapper='true']"));

    if (selectList_Element.Count() > 0)
    {
        // click the first Main Price
        selectList_Element[0].FindElement(By.CssSelector("[data-cy='idp-button-Select']")).Click();

        return true;
    }

    return false;
}

bool selectPriceByUpsellDrawerClick()
{
    IReadOnlyList<IWebElement> selectList_Element = driver.FindElements(By.TagName("idp-upsell-drawer"));

    if (selectList_Element.Count() > 0)
    {
        // click the first Main Price
        string selectButtonId = "mach-drawer-select-cta-MAIN";
        selectList_Element[0].FindElement(By.Id(selectButtonId)).Click();

        return true;
    }

    return false;
}

bool gotoSearchResultPage()
{
    string url = driver.Url;
    bool result = url.StartsWith("https://www.delta.com/flightsearch/book-a-flight");
    if (result)
    {
        string continueButton = "btnSubmit";
        // confirms if the flexible date page shows up
        driver.FindElement(By.CssSelector($"[data-cy={continueButton}]")).Click();
        waitUntilNavigationComplete();
    }

    return true;
}

void selectAirport(string location, string selectorId)
{
    wait.Until(d =>
    {
        try
        {
            var fromAirportName_link = driver.FindElement(By.Id(selectorId));
            fromAirportName_link.Click();

            changeTextboxText(location, "search_input");

            IReadOnlyList<IWebElement> searchResults_Element = driver.FindElement(By.ClassName("search-result-container"))
            .FindElements(By.TagName("li"));

            if (searchResults_Element.Count > 0)
            {
                searchResults_Element[0].Click();
                return true;
            }

            return false;
        }
        catch
        {
            return false;
        }
    });
}

void changeTextboxText(string value, string selectorId)
{
    var searchInput_Textbox = driver.FindElement(By.Id(selectorId));
    searchInput_Textbox.Clear();
    searchInput_Textbox.SendKeys(value);
}

void selectItemFromSelectElement_creditCard(string text, string selectorId)
{
    wait.Until(d =>
    {
        try
        {
            var selectElement = driver.FindElement(By.Id($"{selectorId}-wrapper"));
            selectElement.Click();

            IReadOnlyList<IWebElement> selectList_Element = driver.FindElement(By.Id($"{selectorId}-desc"))
                .FindElements(By.TagName("li"));

            foreach (IWebElement e in selectList_Element)
            {
                if (e.Text.Equals(text))
                {
                    e.Click();
                    break;
                }
            }

            return true;
        }
        catch
        {
            return false;
        }
    });
}

void selectItemFromSelectElement_reviewPage(string text, string selectorId)
{
    wait.Until(d =>
    {
        try
        {
            var selectElement = driver.FindElement(By.Id($"{selectorId}_dropdown"));
            selectElement.Click();

            IReadOnlyList<IWebElement> selectList_Element = driver.FindElement(By.Id($"{selectorId}-desc"))
                .FindElements(By.TagName("li"));

            foreach (IWebElement e in selectList_Element)
            {
                if (e.FindElement(By.TagName("span")).Text.Trim().Equals(text))
                {
                    e.Click();
                    break;
                }
            }

            return true;
        }
        catch
        {
            return false;
        }
    });
}

void selectItemFromSelectElement(string text, string selectorName)
{
    wait.Until(d =>
    {
        try
        {
            string id = $"{selectorName}-desc";
            var selectElement = driver.FindElement(By.CssSelector($"[aria-owns={id}]"));
            selectElement.Click();

            IReadOnlyList<IWebElement> selectList_Element = driver.FindElement(By.Id(id))
                .FindElements(By.TagName("li"));

            foreach (IWebElement e in selectList_Element)
            {
                if (e.Text.Equals(text))
                {
                    e.Click();
                    break;
                }
            }
            return true;
        }
        catch
        {
            return false;
        }
    });
}

void selectDateFromCalendarElement(string date, string selectorId)
{
    var selectElement = driver.FindElement(By.CssSelector($"[datefor={selectorId}]"));
    selectElement.Click();

    string[] splitDate = date.Split('/');

    while (!isCalendarSectionByTitleYear(splitDate[2]))
    {
        calendarNextButtonClick();
    }

    string calendarSectionClassName = getCalendarSectionByTitleMonth(int.Parse(splitDate[0]));
    while (String.IsNullOrEmpty(calendarSectionClassName))
    {
        calendarNextButtonClick();
        calendarSectionClassName = getCalendarSectionByTitleMonth(int.Parse(splitDate[0]));
    }

    calendarDayClick(int.Parse(splitDate[1]), calendarSectionClassName);
}

void calendarDayClick(int day, string selectorClassName)
{
    wait.Until(d =>
    {
        try
        {
            IReadOnlyList<IWebElement> selectList_Element = driver.FindElement(By.ClassName(selectorClassName))
            .FindElements(By.TagName("a"));

            foreach (IWebElement e in selectList_Element)
            {
                if (e.Text.Equals(day.ToString()))
                {
                    e.Click();

                    //click the done button
                    driver.FindElement(By.ClassName("donebutton")).Click();
                    break;
                }
            }

            return true;
        }
        catch
        {
            return false;
        }
    });
}

void calendarNextButtonClick()
{
    var selectElement = driver.FindElement(By.ClassName("dl-datepicker-1"));
    selectElement.Click();
}

string getCalendarSectionByTitleMonth(int month)
{
    string monthName = getMonthName(month);

    if (!String.IsNullOrEmpty(monthName))
    {
        var selectElement = driver.FindElement(By.ClassName("dl-datepicker-month-0"));
        if (selectElement.Text.Equals(monthName))
        {
            return "dl-datepicker-tbody-0";
        }
        else
        {
            selectElement = driver.FindElement(By.ClassName("dl-datepicker-month-1"));
            if (selectElement.Text.Equals(monthName))
            {
                return "dl-datepicker-tbody-1";
            }
        }
    }

    return "";
}

bool isCalendarSectionByTitleYear(string year)
{
    var selectElement = driver.FindElement(By.ClassName("dl-datepicker-year-0"));
    if (selectElement.Text.Equals(year))
    {
        return true;
    }
    else
    {
        selectElement = driver.FindElement(By.ClassName("dl-datepicker-year-1"));
        if (selectElement.Text.Equals(year))
        {
            return true;
        }
    }

    return false;
}

string getMonthName(int month)
{
    switch (month)
    {
        case 1:
            return "January";
            case 2:
            return "February";
            case 3:
            return "March";
            case 4:
            return "April";
            case 5:
            return "May";
            case 6:
            return "June";
            case 7:
            return "July";
        default:
            return "";
    }
}