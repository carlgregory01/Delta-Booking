package Booking;

  
import java.util.logging.Level;
  import org.openqa.selenium.By;
 import org.openqa.selenium.JavascriptExecutor;
  import org.openqa.selenium.WebDriver;
 import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
     import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
 import org.testng.annotations.BeforeMethod;
  import org.testng.annotations.Test;

import utils.log;

  
 

public class FlightBooking {
	public WebDriver driver;
 	  JavascriptExecutor js;

  @BeforeMethod
  public void setUp() throws Exception {
	  
		System.setProperty("webdriver.chrome.silentOutput", "true");        
		java.util.logging.Logger.getLogger("org.openqa.selenium").setLevel(Level.SEVERE);
		  String filePath = System.getProperty("user.dir");
		  
		  System.setProperty("webdriver.chrome.driver",filePath +"//Drivers/chromedriver.exe"); 

		
  }

  @Test
  public void testFlightBooking() throws Exception {
	  
	  ChromeOptions options = new ChromeOptions();
	  options.addArguments("--remote-allow-origins=*");
	 driver = new ChromeDriver(options);
		driver.manage().deleteAllCookies();
    js = (JavascriptExecutor) driver;
   
   
    driver.get("https://www.delta.com");
	 driver.manage().window().maximize();

    Thread.sleep(4000);
    driver.findElement(By.xpath("//*[@id=\"onetrust-accept-btn-handler\"]")).click();
	  log.info("Select Cookies");

    Thread.sleep(4000);
  
  driver.findElement(By.xpath("//*[@id=\"fromAirportName\"]/span[1]")).click();
    driver.findElement(By.id("search_input")).click();
    driver.findElement(By.id("search_input")).clear();
    driver.findElement(By.id("search_input")).sendKeys("JFK");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id='airport-serach-panel']/div/div[2]/div/ul/li/a/span[2]")).click();
    Thread.sleep(2000);
    
    driver.findElement(By.xpath("//*[@id=\"toAirportName\"]/span[1]")).click();
    driver.findElement(By.id("search_input")).click();
    driver.findElement(By.id("search_input")).clear();
    driver.findElement(By.id("search_input")).sendKeys("LAX");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//div[@id='airport-serach-panel']/div/div[2]/div/ul/li/a/span[2]")).click();
    Thread.sleep(2000);
	  log.info("City Selected");

    driver.findElement(By.xpath("//div[@id='booking']/form/div/div/div/div/div[2]/span/span/span")).click();
    driver.findElement(By.id("ui-list-selectTripType0")).click();
    
	  log.info("Roundtrip Selected");
	  Thread.sleep(2000);
    
    driver.findElement(By.xpath("//span[@id='calDepartLabelCont']/span[2]")).click();
    Thread.sleep(2000);
    driver.findElement(By.xpath("//span[normalize-space()='Next']")).click();
    driver.findElement(By.xpath("//span[normalize-space()='Next']")).click();

    driver.findElement(By.linkText("11")).click();
    driver.findElement(By.linkText("24")).click();
    driver.findElement(By.xpath("//button[@value='done']")).click();
    
    log.info("Done Button clicked");
    Thread.sleep(2000);
    
 
    driver.findElement(By.id("btn-book-submit")).click();
    Thread.sleep(10000);
    log.info("Submit Button clicked");
    
 
    driver.findElement(By.xpath("//*[@id=\"grid-row-0-fare-cell-desktop-VSLT\"]/div[2]/idp-fare-cell-price-desktop-template/div/div")).click();
    Thread.sleep(2000);

    driver.findElement(By.xpath("//button[normalize-space()='MOVE TO ECONOMY CLASSIC']")).click();
    Thread.sleep(2000);

    driver.findElement(By.xpath("//button[normalize-space()='Continue to Review & Pay']")).click();
   
    Thread.sleep(4000);

    
     driver.findElement(By.id("firstName_0")).click();
    driver.findElement(By.id("firstName_0")).clear();
    driver.findElement(By.id("firstName_0")).sendKeys("Carlgregory");
    driver.findElement(By.id("lastName_0")).click();
    driver.findElement(By.id("lastName_0")).clear();
    driver.findElement(By.id("lastName_0")).sendKeys("Bobby");
     
    driver.findElement(By.xpath("//*[@id=\"suffix_0option-2\"]")).click();

    driver.findElement(By.xpath("//*[@id=\"dobmonth_0option-3\"]")).click();
    driver.findElement(By.xpath("//*[@id=\"dobday_0option-13\"]")).click();
    driver.findElement(By.xpath("//*[@id=\"dobday_0option-13\"]")).click();
    driver.findElement(By.xpath("//*[@id=\"dobyear_0option-41\"]")).click();

  
  
    
    driver.findElement(By.id("contact_info_phone")).click();
    driver.findElement(By.id("contact_info_phone")).clear();
    driver.findElement(By.id("contact_info_phone")).sendKeys("0798013742");
    driver.findElement(By.id("contact_info_email")).click();
    driver.findElement(By.id("contact_info_email")).clear();
    driver.findElement(By.id("contact_info_email")).sendKeys("carlgreo@gmail.com");
    driver.findElement(By.id("id_paymentCardNum_creditDebit")).click();
    driver.findElement(By.id("id_paymentCardNum_creditDebit")).clear();
    driver.findElement(By.id("id_paymentCardNum_creditDebit")).sendKeys("4921017809999013");
    driver.findElement(By.id("id_expirationDate_creditDebit")).click();
    driver.findElement(By.id("id_expirationDate_creditDebit")).clear();
    driver.findElement(By.id("id_expirationDate_creditDebit")).sendKeys("02/38");
    driver.findElement(By.id("id_paymentCardSecurityCode_creditDebit")).click();
    driver.findElement(By.id("id_paymentCardSecurityCode_creditDebit")).clear();
    driver.findElement(By.id("id_paymentCardSecurityCode_creditDebit")).sendKeys("546");
    driver.findElement(By.id("id_nameOnCard_creditDebit")).click();
    driver.findElement(By.id("id_nameOnCard_creditDebit")).clear();
    driver.findElement(By.id("id_nameOnCard_creditDebit")).sendKeys("Carlgregory Nwagwu");
    driver.findElement(By.id("id_addressLine1Text_creditDebit")).click();
    driver.findElement(By.id("id_addressLine1Text_creditDebit")).clear();
    driver.findElement(By.id("id_addressLine1Text_creditDebit")).sendKeys("JFk Look Road");
    driver.findElement(By.id("id_addressLine2Text_creditDebit")).click();
    driver.findElement(By.id("id_addressLine2Text_creditDebit")).clear();
    driver.findElement(By.id("id_addressLine2Text_creditDebit")).sendKeys("New York");
    driver.findElement(By.id("id_cityLocalityName_creditDebit")).click();
    driver.findElement(By.id("id_cityLocalityName_creditDebit")).clear();
    driver.findElement(By.id("id_cityLocalityName_creditDebit")).sendKeys("Dallas");
    driver.findElement(By.id("id_countrySubdivisionCode_creditDebit-val")).click();
    driver.findElement(By.id("ui-list-id_countrySubdivisionCode_creditDebit4")).click();
    driver.findElement(By.id("id_postalCode_creditDebit")).click();
    driver.findElement(By.id("id_postalCode_creditDebit")).clear();
    driver.findElement(By.id("id_postalCode_creditDebit")).sendKeys("01234");
    log.info("Card Details Entered");
    Thread.sleep(2000);
    driver.findElement(By.xpath("//button[@id='completePurchaseBtn']")).click();
    log.info("Pay Button Clicked");

  }


  @AfterMethod //AfterMethod annotation - This method executes after every test execution
  public void screenShot(ITestResult result){

  driver.quit();
  }}